# Bivot Current Version: 0.2
# Original Program by SOLAR Organization & Red Star Development
# General Public License Version 3.0 (GPLv 3.0)
from bivot_python_func import *

a = str(input("Enter your message: "))
bivot_vol_sub_change(a, b)
bivot_a1_security(a, b)